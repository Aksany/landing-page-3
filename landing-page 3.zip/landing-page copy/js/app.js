/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Define Global Variables
 * 
*/


let sec = document.querySelectorAll('section');//get sections 
const nav = document.getElementById('navbar__list');//get the nav div to append the nav on it





/**
 * End Global Variables
 * Start Helper Functions
 * 
*/
//creat nav function
//looping throw secections to get it attributes "data nav"for the name, and"id" for link

function navigation(section){
  
    secName = section.getAttribute('data-nav');
    secLink = section.getAttribute('id');
  
    //creat li inside ul nav, the add anchor html
    navItem = document.createElement('li');
    navItem.innerHTML=`<a class='menu__link' href='#${secLink}'>${secName}</a>`;//finally the problem was in template string 
    
  //append li inside the nav
    nav.appendChild(navItem);
  
}
sec.forEach(navigation);
  


/*window listener for active section
active section'top <200 & >-300*/
window.addEventListener("scroll", function(){
  for(section of sec){
  if(section.getBoundingClientRect().top<200 && section.getBoundingClientRect().top>-300){
    section.classList.add("your-active-class");
    
  }else{
    section.classList.remove("your-active-class");
    
  }
}
  
})

//trying to add sections dynamically , its working but not efficiently. 

const addSection= document.getElementById('button');
addSection.addEventListener('click',newSection);



function newSection(){
  const wrapper = document.getElementById('bodywrapper');//added div wrape all sections n HTML  
  const newSec=document.createElement('section');// create new section
  newSec.innerHTML=
  `<div class="landing__container">
  <h2>Section </h2>
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi fermentum metus faucibus lectus pharetra dapibus. Suspendisse potenti. Aenean aliquam elementum mi, ac euismod augue. Donec eget lacinia ex. Phasellus imperdiet porta orci eget mollis. Sed convallis sollicitudin mauris ac tincidunt. Donec bibendum, nulla eget bibendum consectetur, sem nisi aliquam leo, ut pulvinar quam nunc eu augue. Pellentesque maximus imperdiet elit a pharetra. Duis lectus mi, aliquam in mi quis, aliquam porttitor lacus. Morbi a tincidunt felis. Sed leo nunc, pharetra et elementum non, faucibus vitae elit. Integer nec libero venenatis libero ultricies molestie semper in tellus. Sed congue et odio sed euismod.</p>

  <p>Aliquam a convallis justo. Vivamus venenatis, erat eget pulvinar gravida, ipsum lacus aliquet velit, vel luctus diam ipsum a diam. Cras eu tincidunt arcu, vitae rhoncus purus. Vestibulum fermentum consectetur porttitor. Suspendisse imperdiet porttitor tortor, eget elementum tortor mollis non.</p>
</div>`;

sec = document.querySelectorAll('section');//get sections array again
let nuOfSec = sec.length;//recalcaulate sections length
let newNuofSec =nuOfSec+1 ;//add one to modify its Id and datanav
newSec.id="section"+newNuofSec;
newSec.setAttribute('data-nav','Section '+newNuofSec);

//Append Newsec
wrapper.appendChild(newSec);
//Updating navbar
sec.forEach(navigation);
}
//End of adding new section code

//GO Up bottun
const upButton = document.getElementById('up');
window.addEventListener('scroll',()=>{
  if (window.pageYOffset>=400){
    upButton.style.display='block';
  }else{
    upButton.style.display='none';
  }
});
upButton.addEventListener('click',()=>{
  window.scrollTo(0,0);
});
// end of GOUp bottun




window.addEventListener('scroll',()=>{
  
  document.getElementById("hidenav").style.display = "block";
    
  } );
  
  
   
  
/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav


// Add class 'active' to section when near top of viewport


// Scroll to anchor ID using scrollTO event


/**
 * End Main Functions
 * Begin Events
 * 
*/

// Build menu 

// Scroll to section on link click

// Set sections as active


